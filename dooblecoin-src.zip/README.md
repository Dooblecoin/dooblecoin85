RPC Port: 42809
Network Port: 42808